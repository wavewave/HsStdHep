extern helpMenuInfo *MainMenuHelp[];
extern helpMenuInfo *MainMenuHelpSpace[];
extern helpMenuInfo *MainMenuHelpPara[];
